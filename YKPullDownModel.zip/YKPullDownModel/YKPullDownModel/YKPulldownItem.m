//
//  YKPulldownItem.m
//  YKPullDownModel
//
//  Created by 王永康 on 15/7/27.
//  Copyright (c) 2015年 王永康. All rights reserved.
//

#import "YKPulldownItem.h"

@implementation YKPulldownItem

//当无子选项时，初始化subitems
- (NSMutableArray *)subitems
{
    if (_subitems == nil) {
        _subitems = [[NSMutableArray alloc] init];
    }
    return _subitems;
}

- (instancetype)initWithDic:(NSDictionary *)dic
{
    self = [super init];
    if (self) {
        self.itemTitle = dic[@"itemTitle"];
        NSArray *subItems = dic[@"subItem"];
        
        NSUInteger count = subItems.count;
        for (int i = 0; i < count; i++) {
            NSString *subItemTitle = subItems[i];
            [self.subitems addObject:subItemTitle];
        }
    }
    return self;
}

+ (instancetype)itemWithDic:(NSDictionary *)dic
{
    return [[self alloc] initWithDic:dic];
}
@end
