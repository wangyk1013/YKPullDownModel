//
//  main.m
//  YKPullDownModel
//
//  Created by 王永康 on 15/7/27.
//  Copyright (c) 2015年 王永康. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
