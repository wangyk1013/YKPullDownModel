//
//  YKPulldownItem.h
//  YKPullDownModel
//
//  Created by 王永康 on 15/7/27.
//  Copyright (c) 2015年 王永康. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YKPulldownItem : NSObject

@property (copy, nonatomic) NSString *itemTitle;
@property (strong, nonatomic) NSMutableArray *subitems;

+ (instancetype)itemWithDic:(NSDictionary *)dic;
@end
