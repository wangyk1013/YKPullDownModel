
//
//  YKPulldownView.m
//  YKPullDownModel
//
//  Created by 王永康 on 15/7/27.
//  Copyright (c) 2015年 王永康. All rights reserved.
//

#import "YKPulldownView.h"

#import "UIView+Extension.h"

#import "YKPulldownItem.h"

#import "YKPulldownTitleView.h"
#import "YKPulldownMenuView.h"

#define YBPulldownScreenW ([UIScreen mainScreen].bounds.size.height)


@interface YKPulldownView ()<YKPulldownMenuViewDelegate>

/** 数据数组*/
@property (strong, nonatomic) NSMutableArray *items;



/** 是否需要重新排序标签按钮 */
@property (assign, nonatomic) BOOL needLoadTitleButton;



/** 是否展开 */
@property (assign, nonatomic) BOOL is_unfold;

@property (weak, nonatomic) YKPulldownMenuView * menu_view;

@property (weak, nonatomic) YKPulldownTitleView * seletedTitleView;

@property (weak, nonatomic) UIImageView * titleBar_imageView;

@end

@implementation YKPulldownView

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.titleBar_imageView.x = 0;
    self.titleBar_imageView.y = 0;
    self.titleBar_imageView.width = self.width;
    self.titleBar_imageView.height = Pulldown_TitleButton_Height;
    
    if (self.needLoadTitleButton){
        [self loadTitleButton];
        self.needLoadTitleButton = NO;
    }
}

- (void)loadTitleButton{
    
    NSInteger count = self.items.count;
    
    if (_itemIndex <= count) {
        YKPulldownItem *item = self.items[_itemIndex];
        YKPulldownTitleView *titleView = nil;
   
        titleView = [[YKPulldownTitleView alloc] initWithFrame:self.bounds];
        
        [titleView addTarget:self action:@selector(titleButtonAction:)];
        [self.titleBar_imageView addSubview:titleView];
        titleView.item = item;
    }
}

- (void)titleButtonAction:(UITapGestureRecognizer *)tap
{
    YKPulldownTitleView *titleView = (YKPulldownTitleView *)tap.view;
    if (titleView == nil) {
        titleView = self.seletedTitleView;
    }
    titleView.isSelected = !titleView.isSelected;
    if (titleView.isSelected) {
        self.seletedTitleView = titleView;
    }
    self.is_unfold = titleView.isSelected;
}

// 展开
- (void)unfoldMenu{
    
    self.menu_view.x = 0;
    self.menu_view.y = Pulldown_TitleButton_Height;
    self.menu_view.width = self.width;
    self.menu_view.backgroundColor = [UIColor whiteColor];
    
    YKPulldownItem *item = self.seletedTitleView.item;
    self.menu_view.items = item.subitems;
    
    [UIView animateWithDuration:0.25 animations:^{
        
        self.height = self.menu_view.unfoldHeight + self.height;
        self.menu_view.height = self.menu_view.unfoldHeight;
    }];
}

// 收起
- (void)packupMenu{
    [UIView animateWithDuration:0.25 animations:^{
        self.menu_view.height = 0;
        
    }completion:^(BOOL finished) {

        self.height = Pulldown_TitleButton_Height;
    }];
}

- (void)clickMarkView:(UITapGestureRecognizer *)tap{
    
    [self titleButtonAction:nil];
}

#pragma mark - YBPulldownMenuViewDelegate


- (void)menuView:(YKPulldownMenuView *)menuView didSelectedItemIndexPath:(NSIndexPath *)indexPath{
    YKPulldownItem * item = self.seletedTitleView.item;
    
    NSIndexPath *item_indexPath = [NSIndexPath indexPathForRow:indexPath.row inSection:[self.items indexOfObject:item]];
    
    if ([self.delegate respondsToSelector:@selector(pulldown:didSeletedItem:atIndexPath:)]){
        [self.delegate pulldown:self didSeletedItem:item atIndexPath:item_indexPath];
    }
    
    if(self.itemTop){
        [self.seletedTitleView setTitle:item.subitems[indexPath.row]];
    }
    
    [self clickMarkView:nil];
}


#pragma mark - Set and Get


-(void)setPlistFileName:(NSString *)plistFileName {
    _plistFileName = plistFileName;
    NSArray *dic_array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:_plistFileName ofType:@"plist"]];
    
    NSUInteger count = dic_array.count;
    
    for (int i=0; i<count; i++) {
        NSDictionary *item_dic = dic_array[i];
        
        YKPulldownItem *item = [YKPulldownItem itemWithDic:item_dic];
        
        [self.items addObject:item];
    }
    self.needLoadTitleButton = YES;
    [self setNeedsLayout];
}


-(void)setIs_unfold:(BOOL)is_unfold{
    _is_unfold = is_unfold;
    if (_is_unfold){
        [self unfoldMenu];
    }else{
        [self packupMenu];
    }
}




-(YKPulldownMenuView *)menu_view{
    if (_menu_view == nil){
        YKPulldownMenuView *menu_view = [[YKPulldownMenuView alloc]init];
        menu_view.delegate = self;
        _menu_view.backgroundColor = [UIColor whiteColor];
        [self addSubview:menu_view];
        _menu_view = menu_view;
    }
    return _menu_view;
}


-(UIImageView *)titleBar_imageView{
    if (_titleBar_imageView == nil){
        UIImageView *titleBar_imageView = [[UIImageView alloc]init];
        titleBar_imageView.image = [[UIImage imageNamed:@"titlebar_background"] stretchableImageWithLeftCapWidth:1 topCapHeight:1];
        titleBar_imageView.clipsToBounds = YES;
        titleBar_imageView.userInteractionEnabled = YES;
        [self addSubview:titleBar_imageView];
        _titleBar_imageView = titleBar_imageView;
    }
    return _titleBar_imageView;
}


-(NSMutableArray *)items{
    if (_items == nil){
        _items = [[NSMutableArray alloc]init];
    }
    return _items;
}



-(void)setBackgroundColor:(UIColor *)backgroundColor{
    [super setBackgroundColor:[UIColor clearColor]];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.clipsToBounds = YES;
        
        //此处设置边框颜色
        self.layer.borderColor = [UIColor lightGrayColor].CGColor;
        self.layer.borderWidth = 1.0f;
    }
    return self;
}


@end
