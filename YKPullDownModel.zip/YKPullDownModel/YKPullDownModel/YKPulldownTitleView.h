//
//  YKPulldownTitleView.h
//  YKPullDownModel
//
//  Created by 王永康 on 15/7/27.
//  Copyright (c) 2015年 王永康. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YKPulldownItem;

@interface YKPulldownTitleView : UIView

@property (nonatomic, strong) YKPulldownItem *item;

@property (nonatomic, copy) NSString *title;
@property (assign ,nonatomic)BOOL isSelected;

- (void)addTarget:(id)target action:(SEL)action;

@end
