//
//  YKPulldownMenuView.m
//  YKPullDownModel
//
//  Created by 王永康 on 15/7/27.
//  Copyright (c) 2015年 王永康. All rights reserved.
//

#import "YKPulldownMenuView.h"
#import "UIView+Extension.h"

#import "YKPulldownItemCell.h"

#define YKPulldownScreenW ([UIScreen mainScreen].bounds.size.height)

@interface YKPulldownMenuView ()<UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) UITableView *itemTableView;

@end

@implementation YKPulldownMenuView


- (void)layoutSubviews
{
    [super layoutSubviews];
    
    [UIView animateWithDuration:0.25 animations:^{
        self.itemTableView.frame = self.bounds;
    }];
}

#pragma mark - UITableViewDataSource

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    YKPulldownItemCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YKPulldownItemCell"];
    
    NSString *itemTitle = self.items[indexPath.row];
    cell.title = itemTitle;
    
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.items.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return self.itemHeight;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.delegate respondsToSelector:@selector(menuView:didSelectedItemIndexPath:)]) {
        [self.delegate menuView:self didSelectedItemIndexPath:indexPath];
    }
}

#pragma mark - SET and GET

- (void)setItems:(NSMutableArray *)items
{
    _items = items;
    CGFloat unfoldHeight = _items.count *self.itemHeight;
    
    CGRect rect = [self convertRect:self.bounds toView:nil];
    
    if (unfoldHeight > YKPulldownScreenW - rect.origin.y) {
        self.unfoldHeight = YKPulldownScreenW - rect.origin.y;
    }else{
        self.unfoldHeight = unfoldHeight;
    }
    
    [self.itemTableView reloadData];
}

- (CGFloat)itemHeight
{
    if (_itemHeight == 0) {
        _itemHeight = 40;
    }
    return _itemHeight;
}

- (UITableView *)itemTableView
{
    if (_itemTableView == nil) {
        UITableView *itemTableView = [[UITableView alloc] initWithFrame:self.bounds style:UITableViewStylePlain];
        [itemTableView registerNib:[UINib nibWithNibName:@"YKPulldownItemCell" bundle:nil] forCellReuseIdentifier:@"YKPulldownItemCell"];
        itemTableView.scrollEnabled = NO;
        itemTableView.dataSource = self;
        itemTableView.delegate = self;
        [self addSubview:itemTableView];
        _itemTableView = itemTableView;
    }
    return _itemTableView;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.clipsToBounds = YES;
        self.userInteractionEnabled = YES;
    }
    return self;
}













@end
