//
//  YKPulldownTitleView.m
//  YKPullDownModel
//
//  Created by 王永康 on 15/7/27.
//  Copyright (c) 2015年 王永康. All rights reserved.
//

#import "YKPulldownTitleView.h"

#import "YKPulldownItem.h"

#import "UIView+Extension.h"

#define IMAGE_WIDTH 30.0f

@interface YKPulldownTitleView ()

@property (strong, nonatomic)UIImageView *imageView;

@property (strong, nonatomic)UILabel *titleLabel;

@end
@implementation YKPulldownTitleView

- (void)layoutSubviews
{
    [super layoutSubviews];
    if (_titleLabel == nil) {
         [self creatView];
    }
}

- (void)creatView
{
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.width - IMAGE_WIDTH, IMAGE_WIDTH)];

    titleLabel.text = @"  请选择";
    titleLabel.font = [UIFont systemFontOfSize:12.0f];
    titleLabel.textColor = [UIColor lightGrayColor];
 
    
    UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(titleLabel.width, 0,IMAGE_WIDTH , IMAGE_WIDTH)];
    //此处设置右边图片
    imageView.image = [UIImage imageNamed:@"button2.png"];
    
    _titleLabel = titleLabel;
    _imageView = imageView;
    
    [self addSubview:imageView];
    [self addSubview:titleLabel];
    
}

#pragma  mark - SET and GET


- (void)setItem:(YKPulldownItem *)item
{
    _item = item;
  //  _titleLabel.text = item.itemTitle;
}

- (void)setTitle:(NSString *)title
{
    _title = [NSString stringWithFormat:@"  %@",title];
    self.titleLabel.text = _title;
}


- (UILabel *)titleLabel
{
    if (_titleLabel == nil) {
        [self creatView];
    }
    return _titleLabel;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.isSelected = NO;
        self.userInteractionEnabled = YES;
       [self creatView];
    }
    return self;
}


#pragma mark Action


- (void)addTarget:(id)target action:(SEL)action
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:target action:action];
    [self addGestureRecognizer:tap];
    
}



@end
