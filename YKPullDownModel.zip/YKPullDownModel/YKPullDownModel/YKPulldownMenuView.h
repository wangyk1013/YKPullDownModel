//
//  YKPulldownMenuView.h
//  YKPullDownModel
//
//  Created by 王永康 on 15/7/27.
//  Copyright (c) 2015年 王永康. All rights reserved.
//

#import <UIKit/UIKit.h>


@class YKPulldownMenuView;

@protocol YKPulldownMenuViewDelegate <NSObject>

- (void)menuView:(YKPulldownMenuView *)menuView didSelectedItemIndexPath:(NSIndexPath *)indexPath;

@end
@interface YKPulldownMenuView : UIView

@property (assign, nonatomic) id<YKPulldownMenuViewDelegate> delegate;

@property (strong, nonatomic) NSMutableArray *items;

@property (assign, nonatomic) CGFloat unfoldHeight;

@property (assign, nonatomic) CGFloat itemHeight;

@end
