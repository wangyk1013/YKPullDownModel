//
//  YKPulldownView.h
//  YKPullDownModel
//
//  Created by 王永康 on 15/7/27.
//  Copyright (c) 2015年 王永康. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "YKPulldownItem.h"

@class YKPulldownView;

/* 标签按钮高度*/

#define Pulldown_TitleButton_Height 30.0f

@protocol YKPulldownViewDelegate <NSObject>

@optional
- (void)pulldown:(YKPulldownView *)pulldownView didSeletedItem:(YKPulldownItem *)item atIndexPath:(NSIndexPath *)indexPath;

@end
@interface YKPulldownView : UIView

@property (assign, nonatomic) id<YKPulldownViewDelegate> delegate;

/** 选项置顶*/
@property (assign, nonatomic) BOOL itemTop;

@property (copy, nonatomic) NSString *plistFileName;

@property (assign, nonatomic) NSUInteger  itemIndex;
@end
