//
//  ViewController.m
//  YKPullDownModel
//
//  Created by 王永康 on 15/7/27.
//  Copyright (c) 2015年 王永康. All rights reserved.
//

#import "ViewController.h"
#import "YKPulldownView.h"

@interface ViewController ()<YKPulldownViewDelegate>

@property (weak, nonatomic) YKPulldownView *pulldownView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.pulldownView.plistFileName = @"YKPulldownItems";
}

#pragma mark - YKPulldownViewDelegate

- (void)pulldown:(YKPulldownView *)pulldownView didSeletedItem:(YKPulldownItem *)item atIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"选择了  %@",item.subitems[indexPath.row] );
}


- (YKPulldownView *)pulldownView
{
    if (_pulldownView == nil){
        YKPulldownView *pulldownView = [[YKPulldownView alloc]initWithFrame:CGRectMake(100, 50, 175, 30)];
        pulldownView.delegate = self;
        pulldownView.itemTop = YES;
        [self.view addSubview:pulldownView];
        _pulldownView = pulldownView;
    }
    return _pulldownView;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
