//
//  YKPulldownItemCell.m
//  YKPullDownModel
//
//  Created by 王永康 on 15/7/27.
//  Copyright (c) 2015年 王永康. All rights reserved.
//

#import "YKPulldownItemCell.h"

@interface YKPulldownItemCell ()

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@end

@implementation YKPulldownItemCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


- (void)setTitle:(NSString *)title
{
    _title = title;
    self.titleLabel.text = title;
}
@end
